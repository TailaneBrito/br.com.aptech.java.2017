/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package armas;

/**
 *
 * @author Aluno
 */
public class Pistolas {
    
    
    public Pistolas(){
        
    
    }
    
    
    public void descricao(){
        
        
        
        System.out.println("Marca....: Winchester");
        System.out.println("Calibre..: 45");
        System.out.println("Ano......: 1947");
    
    }
}
