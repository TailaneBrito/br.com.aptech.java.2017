/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eletronicos;

/**
 *
 * @author Aluno
 */
public class Computador {
    private String marca;
    private double valor;
    private int ano;

    public String getMarca() {
        return marca;
    }

    public double getValor() {
        return valor;
    }

    public int getAno() {
        return ano;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    
    
    
}
