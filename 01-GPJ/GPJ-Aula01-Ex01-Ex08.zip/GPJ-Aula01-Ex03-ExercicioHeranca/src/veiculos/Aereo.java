/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veiculos;

/**
 *
 * @author Aluno
 */
public class Aereo extends Veiculos{
    public String material;
    
    public void voar(){
        System.out.println("Voando");
    }
}
