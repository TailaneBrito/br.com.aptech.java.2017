/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package familia;

/**
 *
 * @author Aluno
 */
public class Filho3 extends Pai {
    
    
    @Override
    public void dancar(){
        System.out.println("Dança Axé");
    }
    
}
