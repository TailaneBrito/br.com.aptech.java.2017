/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intro;

/**
 *
 * @author Aluno
 */
public class Introducao {

    public Introducao() {
        System.out.println("*************************************** \n");
        System.out.println("***     Bem vindo ao Programa!      ***");
        System.out.println("                24/09/2016             ");
        System.out.println("        Guia de Programção Java         ");
        System.out.println("***************************************");
    }
    
    public void despedita(){
        
        System.out.println("       Obrigado por usar o programa    ");
        System.out.println("            Volte Sempre!!             ");
        
    }
    
    
}
