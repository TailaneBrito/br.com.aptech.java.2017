/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author tailaneb
 */
public class Caninos extends Mamiferos {

    @Override
    public void ruido() {
        System.out.println("auau!");
    }
    
}
