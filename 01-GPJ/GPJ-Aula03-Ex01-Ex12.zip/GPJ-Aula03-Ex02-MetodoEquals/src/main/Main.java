/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Aluno
 */
public class Main {
     
    
    public static void main(String[] args) {
       String nome1 = "Bruno";
       String nome2 = "Bruno";
       
        if (nome1.equals(nome2)) {
            System.out.println("Nomes iguais");
        }else{
            System.out.println("Nomes diferentes");
        }
        
    }
}
