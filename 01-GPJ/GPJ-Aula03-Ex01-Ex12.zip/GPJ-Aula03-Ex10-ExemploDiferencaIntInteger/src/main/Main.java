/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Aluno
 */
public class Main {
    public static void main(String[] args) {
        int a1 = 10;
        Integer a2 = 10;
        
        System.out.println("a1 = " + a1);
        System.out.println("a2 = " + a2);
        
        
        if (a2.equals(a1)) {
            System.out.println("Iguais ");
        }else{
            System.out.println("Diferentes");
        }
        
        
    }
}
