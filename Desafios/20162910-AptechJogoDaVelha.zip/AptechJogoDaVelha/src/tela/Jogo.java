/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author tailaneb
 */
public class Jogo extends JFrame {

    public static int pos, valor;
    public static String marca;
    private static JButton[] botoes = new JButton[9];
    private static ArrayList lista = new ArrayList();
    private static int[] arrayX = new int[9];
    private static Random r = new Random();
    private static boolean vezJogador;
    private static int cont=0;

    public Jogo() {
        JFrame janela = new JFrame();
        JPanel tabuleiro = new JPanel(new GridLayout(3, 3));

        botoes[0] = new JButton();
        botoes[1] = new JButton();
        botoes[2] = new JButton();
        botoes[3] = new JButton();
        botoes[4] = new JButton();
        botoes[5] = new JButton();
        botoes[6] = new JButton();
        botoes[7] = new JButton();
        botoes[8] = new JButton();

        botoes[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 0;
                posicao(pos);
            }
        });

        botoes[1].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 1;
                posicao(pos);
            }
        });

        botoes[2].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 2;
                posicao(pos);
            }
        });

        botoes[3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 3;
                posicao(pos);
            }
        });

        botoes[4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 4;
                posicao(pos);
            }
        });

        botoes[5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 5;
                posicao(pos);
            }
        });

        botoes[6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 6;
                posicao(pos);
            }
        });

        botoes[7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 7;
                posicao(pos);
            }
        });

        botoes[8].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                pos = 8;
                posicao(pos);
            }
        });

        tabuleiro.add(botoes[0]);
        tabuleiro.add(botoes[1]);
        tabuleiro.add(botoes[2]);
        tabuleiro.add(botoes[3]);
        tabuleiro.add(botoes[4]);
        tabuleiro.add(botoes[5]);
        tabuleiro.add(botoes[6]);
        tabuleiro.add(botoes[7]);
        tabuleiro.add(botoes[8]);

        janela.add(tabuleiro);
        janela.setVisible(true);
        janela.setSize(250, 300);
        janela.setTitle("Jogo da Velha");
        janela.setResizable(false);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void posicao(int posicao) {
        
        vezJogador = true;
     
        marca = "O";//adicionando O onde clicou
        botoes[pos].setText(marca); // escrevendo O no botao

        posicao = pos; //adicionando a posicao enviada na lista.
        lista.add(posicao);
        
        
        vezJogador = false; 
        if (lista.contains(pos) || valor == pos) { //existe essa posicao no array?
            //se sim, tirar um numero diferente
            do {
                if (lista.size() < 8) {

                    while (posicao == valor || lista.contains(valor)) {
                        valor = r.nextInt(9);//tirar um numero aleatorio entre 0-8
                    }

                }

            } while (valor == pos);//enquanto o valor for igual a posicao

            marca = "X";//escreve X na tela
            lista.add(valor);//adiciona na lista

            botoes[valor].setEnabled(false);
            botoes[valor].setText(marca);

            botoes[pos].setEnabled(false);
            System.out.println(lista);
        }
        
        
        
    }
}
