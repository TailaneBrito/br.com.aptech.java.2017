/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.contabancaria;

/**
 *
 * @author Aluno
 */
public class ContaEspecial extends ContaBancaria{
    public float limite;
    
    public float sacar(float num){ 
        System.out.println("Sacando " + num);
        if(this.saldo < 0){
            if(this.limite > 0){
            System.err.println("Saque do limite");
            return this.limite -= num;
            }else{
                System.out.println("saldo negativo em conta");
                return 0;
            }
        }else{
            return this.saldo -= num;
           
        }
    }
}
