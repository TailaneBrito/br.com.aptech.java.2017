/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.contabancaria;

/**
 *
 * @author Aluno
 */
public class ContaBancaria {
    public String cliente;
    public int num_conta;
    public float saldo;
    
    public float sacar(float num){ 
        if(this.saldo < 0){
            System.err.println("saldo negativo");
            return 0;
        }else{
            return this.saldo -= num;
           
        }
    }
    
    public float depositar(float num){
        return this.saldo += num;
    }
}
