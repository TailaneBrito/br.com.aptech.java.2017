/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.contabancaria;

/**
 *
 * @author Aluno
 */
public class ContaPoupanca extends ContaBancaria{
    
    public int diaRendimento;
    
    public float calcNovoSaldo(float taxa){
        System.out.println("Juros de aniversario da conta");
       return (this.saldo * taxa) + this.saldo;
    }
}
