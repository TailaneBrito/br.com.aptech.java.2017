/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import empresa.Funcionario2;
import profissional.Funcionario;


/**
 *
 * @author Aluno
 */
public class Main {
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario();
        Funcionario2 f2 = new Funcionario2();
        f1.ferias();
         
    }
   
    
    
 
}
