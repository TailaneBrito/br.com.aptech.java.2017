package main;

import banco.Cambio;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Cambio valor = new Cambio();
        
        System.out.println("Digite um valor em dollar");
        double real = leitor.nextDouble();
        
        System.out.println("Digite a Taxa de Cambio");
        double taxa = leitor.nextDouble();
                            
        System.out.println("USD " +real + " são "  + "R$ " +valor.converteDollarReal(real, taxa));
    }
}
