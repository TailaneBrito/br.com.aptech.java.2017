
package banco;

public class Cambio {
    
    public double converteDollarReal(double valor, double cambio){
        return valor * cambio;
    }
}
