public class Veiculos {
    String marca;
    String cor;
    double preco;
}
