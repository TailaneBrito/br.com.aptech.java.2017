public class Main {

    
    public static void main(String[] args) {
        Veiculos fusca = new Veiculos();
        Veiculos onibus = new Veiculos();
        
        fusca.cor = "Azul";
        fusca.marca = "Volkswagen";
        fusca.preco = 18000;
        
        onibus.cor = "Cinza";
        onibus.marca = "Mercedes bens";
        onibus.preco = 45000;
        
        System.out.println(
                "Fusca"                     + "\n" +
                "Cor..............: "       + fusca.cor + "\n" +
                "Marca............: "       + fusca.marca + "\n" +
                "Preço............: "      + fusca.preco + "\n"
        );
        
        System.out.println(
                "Onibus"                     + "\n" +
                "Cor..............: "       + onibus.cor + "\n" +
                "Marca............: "       + onibus.marca + "\n" +
                "Preço............: "      + onibus.preco + "\n"
        );
    }
    
}
