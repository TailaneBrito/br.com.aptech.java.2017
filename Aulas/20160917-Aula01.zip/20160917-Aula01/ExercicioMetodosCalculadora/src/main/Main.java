package main;

import calculadora.Calculadora;

public class Main {

    public static void main(String[] args) {
        double x, y, resp;

        x = 4;
        y = 5;

        Calculadora teclaSoma = new Calculadora();

        resp = teclaSoma.somar(x, y);

        System.out.println("Resposta: " + resp);
    }
}
