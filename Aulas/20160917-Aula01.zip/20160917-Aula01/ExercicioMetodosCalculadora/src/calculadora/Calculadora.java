
package calculadora;

public class Calculadora {
    public double somar(double a, double b){
        return a+b;
    }
}
