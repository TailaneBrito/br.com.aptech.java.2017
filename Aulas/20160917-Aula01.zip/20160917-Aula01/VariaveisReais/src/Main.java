
public class Main {

    public static void main(String[] args) {
        double n1 = 10;
        double n2 = 20;
        double soma = 0;
        
        soma = n1 + n2;
        
        System.out.println("A soma é: " + soma);
    }
    
}
