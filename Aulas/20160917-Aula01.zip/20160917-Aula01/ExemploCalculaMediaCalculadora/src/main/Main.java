
package main;

import calculadora.Calculadora;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Calculadora teclaMedia = new Calculadora();
        
        double x, y, z, resposta;
        x = 5;
        y = 5;
        z = 3;
        
        resposta = teclaMedia.calculaMedia(x,y , z);
        
        System.out.println("Media sem Scanner= " + resposta);
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Digite o valor de n1: ");
        double n1 = leitor.nextDouble();
        
        System.out.println("Digite o valor de n2: ");
        double n2 = leitor.nextDouble();
        
        System.out.println("Digite o valor de n3: ");
        double n3 = leitor.nextDouble();
        
        resposta = teclaMedia.calculaMedia(n1, n2, n3);
        
        System.out.println("Media com Scanner = " + resposta);
        
    }
}
