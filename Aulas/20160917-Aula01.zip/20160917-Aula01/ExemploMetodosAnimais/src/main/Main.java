package main;

import animais.Cachorro;
import animais.Gato;
import animais.Passaro;

public class Main {

    public static void main(String[] args) {
        Cachorro pitbull = new Cachorro();
        pitbull.latir();
        pitbull.morder();
        
        Passaro picapau = new Passaro();
        picapau.piar();
        
        Gato frajola = new Gato();
        frajola.miar();
        
    }
}
