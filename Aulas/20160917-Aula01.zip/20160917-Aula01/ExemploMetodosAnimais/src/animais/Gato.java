
package animais;

public class Gato {
    
    public void miar(){
        System.out.println("miau, miau!");
    }
}
