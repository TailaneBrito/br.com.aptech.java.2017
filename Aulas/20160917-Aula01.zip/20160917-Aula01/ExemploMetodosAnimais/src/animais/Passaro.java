
package animais;


public class Passaro {
    
    public void piar(){
        System.out.println("piu, piu!");
    }
}
