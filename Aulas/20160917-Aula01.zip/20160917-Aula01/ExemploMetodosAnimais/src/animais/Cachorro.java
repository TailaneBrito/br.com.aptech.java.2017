
package animais;

public class Cachorro {
    
    public void latir(){
        System.out.println("Au, au!");
    }
    
    public void morder(){
        System.out.println("Nhoc!!!!!");
    }
}
