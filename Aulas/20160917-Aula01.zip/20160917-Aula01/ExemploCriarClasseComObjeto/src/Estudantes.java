
public class Estudantes {
    public String nome;
    public int idade;
    public String dataNascimento;
    public String telefone;
}
