
public class Main {

    public static void main(String[] args) {
       
        Estudantes aluno1 = new Estudantes();
        
        aluno1.nome = "Tailane Brito";
        aluno1.dataNascimento = "01/05/1995";
        aluno1.idade = 21;
        aluno1.telefone = "(11) 98201-2329";
        
        System.out.println(
                "Aluno 1"                     + "\n" +
                "Nome..............: "      + aluno1.nome + "\n" +
                "Data de Nascimento: "      + aluno1.dataNascimento + "\n" +
                "Idade.............: "      + aluno1.idade + "\n" +
                "Telefone..........: "      + aluno1.telefone);
    }
    
}
