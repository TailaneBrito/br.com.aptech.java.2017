package quadrinhos;

public class Viloes {

    public String nome;
    public String superPoder;
    public int idade;
}
