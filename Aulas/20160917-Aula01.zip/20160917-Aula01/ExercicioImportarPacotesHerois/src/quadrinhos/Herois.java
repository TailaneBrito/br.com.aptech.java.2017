package quadrinhos;

public class Herois {

    public String nome;
    public String superPoder;
    public int idade;
}
