
package main;

import quadrinhos.Herois;
import quadrinhos.Viloes;


public class Main {
    public static void main(String[] args) {
        Herois hero1 = new Herois();
        Viloes vilao1 = new Viloes();
        
        hero1.nome = "Batman";
        hero1.idade = 35;
        hero1.superPoder = "BatRangue";
        
        vilao1.nome = "Coringa";
        vilao1.idade = 54;
        vilao1.superPoder = "Cartas";
        
        
        System.out.println("Heroi 1" + "\n" 
                + "Nome.......: "    + hero1.nome       + "\n"
                + "Idade......: "    + hero1.idade      + "\n"
                + "Super Poder: "    + hero1.superPoder + "\n" 
        );
        
        System.out.println("Vilao 1" + "\n" 
                + "Nome.......: "    + vilao1.nome      + "\n"
                + "Idade......: "    + vilao1.idade     + "\n"
                + "Super Poder: "    + vilao1.superPoder
        );
    }
}
