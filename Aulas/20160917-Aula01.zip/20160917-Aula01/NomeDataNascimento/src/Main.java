
public class Main {


    public static void main(String[] args) {
        System.out.println("Tailane Brito");
        System.out.println("01/05/1995");
    }
    
}
