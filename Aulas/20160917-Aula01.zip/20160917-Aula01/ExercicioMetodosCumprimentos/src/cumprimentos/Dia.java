package cumprimentos;

public class Dia {

    public void bomDia() { 
        System.out.println("Bom dia!");
    }
}
