package cumprimentos;

public class Noite {

    public void boaNoite() {
        System.out.println("Bom noite!");
    }
}
