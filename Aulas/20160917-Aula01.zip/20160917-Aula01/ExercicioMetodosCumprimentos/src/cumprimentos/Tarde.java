package cumprimentos;

public class Tarde {

    public void boaTarde() {
        System.out.println("Boa tarde!");
    }
}
