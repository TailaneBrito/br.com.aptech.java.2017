package main;

import cumprimentos.Dia;
import cumprimentos.Noite;
import cumprimentos.Tarde;

public class Main {

    public static void main(String[] args) {
        Dia manha = new Dia();
        Tarde tarde = new Tarde();
        Noite noite = new Noite();

        manha.bomDia();
        tarde.boaTarde();
        noite.boaNoite();
    }
}
