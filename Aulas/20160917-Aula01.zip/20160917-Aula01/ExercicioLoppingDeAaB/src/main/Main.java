
package main;

import java.util.Scanner;
import laco.Laco;


public class Main {
    public static void main(String[] args) {
    Laco l = new Laco(); 
   
    Scanner n = new Scanner(System.in);
    
        System.out.println("Digite um numero de comeco do laço");
        int inicio = n.nextInt();
        
        System.out.println("Digite um numero de fim do laço");
        int fim = n.nextInt();
        
        l.mostrar2(inicio, fim);
    
    }
 
    
   
   
}
