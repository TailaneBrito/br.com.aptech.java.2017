package laco;

public class Laco {

    public void mostrar2(int a, int b) {

        if (a < b) {
            for (int i = a; i < b + 1; i++) {
                System.out.println("Monstrando " + i + " de " + b);
            }
        } else {
            for (int i = a; i >= b; i--) {
                System.out.println("Monstrando " + i + " de " + b);
            }
        }
    }
}
