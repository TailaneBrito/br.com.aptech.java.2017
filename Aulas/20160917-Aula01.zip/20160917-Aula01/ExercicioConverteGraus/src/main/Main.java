
package main;

import converteGraus.ConverteGraus;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ConverteGraus cg = new ConverteGraus();
        
        System.out.println("Digite o valor em Celsius");
        double c = s.nextDouble();
                
        double resp1 = cg.converteCelsiusParaFahrenheit(c);
        System.out.println(c + "Cº sao " + resp1 + "Fº");
        
        System.out.println("Digite o valor em Fahrenheit");
        double f = s.nextDouble();
        
        double resp2 = cg.converteFahrenheitParaCelsius(f);
        System.out.println(f + "Fº sao " + resp2);
        
        
     
    }
 
}
