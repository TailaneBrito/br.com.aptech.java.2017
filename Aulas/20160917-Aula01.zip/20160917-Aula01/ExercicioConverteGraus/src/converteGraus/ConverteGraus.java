
package converteGraus;


public class ConverteGraus {
    public double converteCelsiusParaFahrenheit(double c){
        return (c*1.8)+32; 
    }
    
    public double converteFahrenheitParaCelsius(double f){
        double sub = f-32;
        double div;
        
        return div = sub/1.8;
    }
}
