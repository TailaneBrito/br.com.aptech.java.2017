
package main;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        double valor1;
        double valor2;
        
        System.out.println("Digite um número");
        valor1 = leitor.nextInt();
        System.out.println("Digite outro número");
        valor2 = leitor.nextInt();
        
        System.out.println("Os valores digitados foram: " + valor1 + " e " + valor2 );
        
    }
}
