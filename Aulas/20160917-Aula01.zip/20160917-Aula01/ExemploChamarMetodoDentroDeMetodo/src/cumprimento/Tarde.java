package cumprimento;

public class Tarde {

    public void boaTarde() {
        System.out.println("Boa Tarde!");
    }
}
