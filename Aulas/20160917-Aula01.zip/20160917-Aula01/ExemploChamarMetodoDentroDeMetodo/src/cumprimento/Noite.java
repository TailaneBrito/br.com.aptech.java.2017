package cumprimento;

public class Noite {

    public void boaNoite() {
        System.out.println("Boa Noite!");
    }
}
