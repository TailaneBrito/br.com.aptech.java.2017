package cumprimento;

public class Menu {

    public void mostrar() {
        Dia d = new Dia();
        Noite n = new Noite();
        Tarde t = new Tarde();

        d.bomDia();
        n.boaNoite();
        t.boaTarde();
    }
}
