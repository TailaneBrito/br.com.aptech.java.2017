
public class Main {

    public static void main(String[] args) {
        Animais a1 = new Animais();
        Animais a2 = new Animais();

        a1.peso = 10.78;
        a2.peso = 3.87;

        if (a1.peso > a2.peso) {
            System.out.println("a1 mais pesado que a2");
        } else {
            System.out.println("a2 mais pesado que a1");
        }
    }

}
