
public class Animais {
    public String nome;
    public double peso;
    public String raca;
}
