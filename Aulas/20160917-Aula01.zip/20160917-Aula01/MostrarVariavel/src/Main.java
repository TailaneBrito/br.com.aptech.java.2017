
public class Main {

  
    public static void main(String[] args) {
        String nome = "Tailane";
        
        System.out.println("o nome é: " + nome);
    }
    
}
