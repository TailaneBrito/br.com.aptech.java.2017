public class Animais {
    
}
