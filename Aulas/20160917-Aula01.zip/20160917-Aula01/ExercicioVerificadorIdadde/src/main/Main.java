
package main;

import verificador.Verificador;

public class Main {
    public static void main(String[] args) {
        Verificador v1 = new Verificador();
        
        v1.verificarIdade(16);
    }
}
