
package verificador;

public class Verificador {
    public void verificarIdade(int x){
        if (x >= 18){
            System.out.println("Maior de idade");
        }else{
            System.out.println("Menor de idade");
        }
    }
}
