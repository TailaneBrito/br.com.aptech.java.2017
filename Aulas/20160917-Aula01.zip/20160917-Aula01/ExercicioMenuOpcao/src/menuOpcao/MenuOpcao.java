
package menuOpcao;

public class MenuOpcao {
    public void mostraOpcoes(int opcao){
        if(opcao == 1){
            System.out.println("Opcao 1");
        }else if(opcao == 2){
            System.out.println("Opcao 2");
        }else if(opcao ==3){
            System.out.println("Opcao 3");
        }else if(opcao == 4){
            System.out.println("Opcao 4");
            
        }else{
            System.out.println("Opcao Invalida");
        };
    }
}
