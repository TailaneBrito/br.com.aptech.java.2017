package main;

import java.util.Scanner;
import menuOpcao.MenuOpcao;

public class Main {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        MenuOpcao menuOpc = new MenuOpcao();
        
        
        System.out.println("Digite uma opcao entre 1-4");
        int opc = leitor.nextInt();
        
        menuOpc.mostraOpcoes(opc);
        
    }

}
