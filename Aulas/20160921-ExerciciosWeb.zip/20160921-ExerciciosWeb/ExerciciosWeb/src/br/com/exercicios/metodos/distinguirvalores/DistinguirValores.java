
package br.com.exercicios.metodos.distinguirvalores;

public class DistinguirValores {
    
    public boolean isPositive(float num){
        if (num >= 0){
            System.out.println("0. Positivo");
            return true;
        
        }else{
            System.out.println("0. Negativo");
            return false;
        }
    }
       
    public boolean isZero(float num){
        if (num == 0){
            System.out.println("1. É nulo");
            return true;
        }else{
            System.out.println("1. Não é nulo");
            return false;
        }
    }    
        
   
}
