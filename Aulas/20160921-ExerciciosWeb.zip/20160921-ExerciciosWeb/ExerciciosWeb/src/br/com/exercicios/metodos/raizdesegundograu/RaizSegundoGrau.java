
package br.com.exercicios.metodos.raizdesegundograu;

import br.com.exercicios.metodos.delta.Delta;

public class RaizSegundoGrau {
    public void calculaRaizSegundoGrau(float a, float b, float c){
        if(a == 0){
            System.out.println("3. nao existe raiz de segundo grau a = 0");
        }else{
            Delta dt = new Delta();
           
            if(dt.acharDelta(a, b, c) >= 0){
                System.out.println("3. Raizes iguais");
                                
            }else{
                
                float resp = a + (b*c);
                System.out.println("3. Raizes complexas " + resp);
            }
        }
        
        
        
        
        
        
        
    
    }
}
