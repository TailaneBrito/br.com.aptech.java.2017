package br.com.exercicios.metodos.mdc;

import br.com.exercicios.metodos.maiorvalor.MaiorValor;
import br.com.exercicios.metodos.menorvalor.MenorValor;

public class MaximoDivisorComum {

    public float mdcDivisaoSucessiva(float a, float b) {

        MaiorValor mv = new MaiorValor();
        MenorValor mnv = new MenorValor();
        float proximo;
        float anterior;

        float max = mv.calculaMaiorValor(a, b);
        float min = mnv.calculaMenorValor(a, b);

        System.out.println("max " + max + " min " + min);
        proximo = max % min;
        
        System.out.println(max + " / " + min + " = " + proximo);
        
        
        for (float i = proximo; i > 0; i=anterior) {
            
            anterior = min % proximo;
            System.out.println(min + " / " + proximo + " = " + min/proximo);
            min = proximo;
            
            proximo=anterior;
            
            if(anterior==0){
                System.out.println("MDC " + min);
                return min;
            }     
        }
        
        //System.out.println("min " + min);
        return min;
        
    }
    
    
    public float mdcNumerosPrimos(float a, float b){
        
        if(mdcDivisaoSucessiva(a, b) == 1){
            System.out.println("Primos entre si");
        }
        
        return 0;
    
    }
}
