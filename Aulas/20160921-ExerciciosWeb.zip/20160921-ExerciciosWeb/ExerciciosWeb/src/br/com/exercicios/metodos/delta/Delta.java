
package br.com.exercicios.metodos.delta;

public class Delta {
  public float acharDelta(float a, float b, float c){
      float formula = ((b*b) - (4 * a * c));
      System.out.println("2. Delta " + formula);
      return formula;
  }  
}
