
package br.com.exercicios.metodos.sorteio;

import java.util.Random;

public class Dado {
    public int dado(){
        Random r = new Random();
            int resp = r.nextInt(6) + 1;
            System.out.print(" " + resp + "\n");
           
        return resp;
    }
}
