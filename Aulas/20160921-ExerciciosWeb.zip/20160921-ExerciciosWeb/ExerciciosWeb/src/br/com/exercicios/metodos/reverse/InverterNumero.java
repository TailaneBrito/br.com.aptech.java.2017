package br.com.exercicios.metodos.reverse;

public class InverterNumero {

    public void inverteNumero(int numero) {

        if (numero < 10) {
            System.out.print(numero);
            return;
        }else{
            
            System.out.print(numero%10);
            //System.out.print();
            inverteNumero((numero/10));
           // System.out.print(numero/10);
        }

    }

}
