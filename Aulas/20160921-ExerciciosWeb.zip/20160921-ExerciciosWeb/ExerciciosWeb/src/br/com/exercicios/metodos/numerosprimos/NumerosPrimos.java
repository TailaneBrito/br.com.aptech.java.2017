package br.com.exercicios.metodos.numerosprimos;

public class NumerosPrimos {

    public void calculaNumeroPrimo(double numero) {
        int cont = 0;
        int num = 0;
        double resp;

        for (double i = 1; i <= numero; i++) {
            for (double j = 1; j <= i; j++) {
                resp = i % j;
                if (resp == 0) {
                    cont++;
                    num = cont;
                }
            }
            if (num == 2) {
                System.out.println(i + " é primo");
            }else{
                //para mostrar so os primos retirar o else.
                System.out.println(i + " nao é primo");
            }
            cont = 0;
        }
    }

    public boolean calculaPar(int a) {
        if (a % 2 == 0) {
            System.out.println("par");
            return true;
        } else {
            System.out.println("impar");
            return false;
        }

    }
}
