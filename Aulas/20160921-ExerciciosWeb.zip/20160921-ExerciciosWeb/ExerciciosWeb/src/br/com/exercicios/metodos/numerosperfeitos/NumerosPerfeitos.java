package br.com.exercicios.metodos.numerosperfeitos;

public class NumerosPerfeitos {
    //soma dos seus fatores tem que ser igual a ele mesmo.

    public void calcNumPerfeito(int numero) {
        double fator;
        double cont = 0;
        double num;
        double proximo;

        for (double i = 1; i <= numero; i++) {
            //System.out.println("\n ");
            System.out.println("Numero (" + i + ")");

            cont = 0;

            for (double j = 1; j <= i; j++) {

                fator = i % j;

                //num = j;
                if (fator == 0 && i != j) {
                    num = j;

                    proximo = cont;

                    //System.out.println(" " + j);
                    cont += j;

                    if (cont == i) {

                        System.out.println("Numero (" + i + ")" + " é perfeito");
                    }
                }
            }

            //System.out.println("Soma dos Fatoriais: " + cont);
        }

    }

    public float soma(float num) {

        return 0;
    }
}

//            for (double j = i; j <= i; j++) {
//                //System.out.println("J "+ j);
//                resp = i % j;
//
//                if (resp == 0 && j != numero) {
//                    System.out.println("  " +j);
//                    num = j;
//                    cont = num + j;
//
//                    if (cont == numero) {
//                        System.out.println(j);
//                        System.out.print(i + " é perfeito");
//                    }
//}
//}

