
package br.com.exercicios.metodos.maiorvalor;

public class MaiorValor {
  public float calculaMaiorValor(float a, float b){
      if (a > b){
          //System.out.println("4. " + a + " é maior que " + b);
          return a;
      }else if (b > a){
          //System.out.println("4. " + b + " é maior que " + a);
          return b;
      }else{
          //System.out.println("4. " + "Numeros iguais");
          return 0;
      }
   
  }
  
  public float calculaMaiorValor(float a, float b, float c){
      float resp = (Math.max(a, Math.max(b, c)));
      System.out.println("6. o mior numero entre " + a + ", " + b + 
              ", " + c + " é " + resp);
      
      return resp;
  }
  
}
