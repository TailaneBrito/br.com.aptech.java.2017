
package br.com.exercicios.metodos.menorvalor;


public class MenorValor {
    public float calculaMenorValor(float a, float b){
        if(a < b){
            //System.out.println("5. " + a + " é menor que " + b);
            return a;
        }else if(b < a){
            //System.out.println("5. " + b + " é menor que " + a);
            return b;    
        }else{
            //System.out.println("5. " + "Numeros iguais");
            return 0;
        }
    } 
    
    public float calculaMenorValor(float a, float b, float c){
        float resp = (Math.min(a, Math.min(b, c)));
        System.out.println("7. o menor numero entre " + a + ", " + b + 
              ", " + c + " é " + resp);
        
        return resp;
    }
}
