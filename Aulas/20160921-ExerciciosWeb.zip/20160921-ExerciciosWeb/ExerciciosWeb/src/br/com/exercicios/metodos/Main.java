
package br.com.exercicios.metodos;

import br.com.exercicios.metodos.distinguirvalores.DistinguirValores;
import br.com.exercicios.metodos.delta.Delta;
import br.com.exercicios.metodos.maiorvalor.MaiorValor;
import br.com.exercicios.metodos.mdc.MaximoDivisorComum;
import br.com.exercicios.metodos.menorvalor.MenorValor;
import br.com.exercicios.metodos.numerosperfeitos.NumerosPerfeitos;
import br.com.exercicios.metodos.numerosprimos.NumerosPrimos;
import br.com.exercicios.metodos.prova.MediaCalculada;
import br.com.exercicios.metodos.raizdesegundograu.RaizSegundoGrau;
import br.com.exercicios.metodos.reverse.InverterNumero;
import br.com.exercicios.metodos.sorteio.Dado;
import br.com.exercicios.metodos.sorteio.LancaDado;

public class Main {
    public static void main(String[] args) {
       // DistinguirValores dv = new DistinguirValores();
        
       // dv.isPositive(16);
       // dv.isPositive(-1);
        
       // dv.isZero(7);
       // dv.isZero(0);
        
       // Delta dt = new Delta();
       // dt.acharDelta(1, 0, 0);
              
       // RaizSegundoGrau rz = new RaizSegundoGrau();
       // rz.calculaRaizSegundoGrau(1, 1, 1);
        
       // MaiorValor mv = new MaiorValor();
       // mv.calculaMaiorValor(15, -1);
        
       // MenorValor mnv = new MenorValor();
       // mnv.calculaMenorValor(0, 0);
        
       // mv.calculaMaiorValor(1, 6, 19);
       // mnv.calculaMenorValor(1, -1, 0);
        
        //Dado d = new Dado();
        //d.dado();
        
       // LancaDado ld = new LancaDado();
        //ld.lancaUmMilhao();
        
       // MediaCalculada mc = new MediaCalculada();
       // mc.calculaMedia(10, 8, 9);
        
        //NumerosPrimos np = new NumerosPrimos();
        //np.calculaPar(45);
        //np.calculaNumeroPrimo(79);
        
        //MaximoDivisorComum mdc = new MaximoDivisorComum();
        //mdc.mdcDivisaoSucessiva(48, 30);
        //mdc.mdcNumerosPrimos(35,24);
        
        //NumerosPerfeitos np = new NumerosPerfeitos();
        //np.calcNumPerfeito(100);
        
        InverterNumero i = new InverterNumero();
        i.inverteNumero(123);
        
        
    }
    
    
}