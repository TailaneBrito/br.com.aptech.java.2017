package br.com.exercicios.metodos.sorteio;

public class LancaDado {

    public void lancaUmMilhao() {
        int c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0;
        float numVezes=1000000;
        float perc1=0,perc2=0,perc3=0,perc4=0,perc5=0,perc6=0;
        Dado d = new Dado();
        for (float i = 1; i <= numVezes; i++) {
            
            switch (d.dado()) {
                case 1:
                    c1++;
                    perc1 = (c1 * 100)/numVezes;
                    continue;
                case 2:
                    perc2 = (c2 * 100)/numVezes;
                    c2++;
                    continue;
                case 3:
                    c3++;
                    perc3 = (c3 * 100)/numVezes;
                    continue;
                case 4:
                    c4++;
                    perc4 = (c4 * 100)/numVezes;
                    continue;
                case 5:
                    c5++;
                    perc5 = (c5 * 100)/numVezes;
                    continue;
                case 6:
                    c6++;
                    perc6 = (c6 * 100)/numVezes;
                    continue;
            }

        }
        System.out.println("9. O numero 1 foi lancado "
                            + c1 + " vezes" + " com perc " + perc1);         
                
        System.out.println("9. O numero 2 foi lancado "
                            + c2 + " vezes" + " com perc " + perc2);
        System.out.println("9. O numero 3 foi lancado "
                            + c3 + " vezes" + " com perc " + perc3);
        System.out.println("9. O numero 4 foi lancado "
                            + c4 + " vezes" + " com perc " + perc4);
        System.out.println("9. O numero 5 foi lancado "
                            + c5 + " vezes" + " com perc " + perc5);
        System.out.println("9. O numero 6 foi lancado "
                            + c6 + " vezes" + " com perc " + perc6);

    }

}