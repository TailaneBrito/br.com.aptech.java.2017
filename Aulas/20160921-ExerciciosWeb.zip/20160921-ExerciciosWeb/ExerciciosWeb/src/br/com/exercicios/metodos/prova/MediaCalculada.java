package br.com.exercicios.metodos.prova;

import br.com.exercicios.metodos.maiorvalor.MaiorValor;
import br.com.exercicios.metodos.menorvalor.MenorValor;

public class MediaCalculada {

    public void calculaMedia(float a, float b, float c) {
        MaiorValor maiorNota = new MaiorValor();
        MenorValor menorNota = new MenorValor();

        float media3 = (a + b + c) / 3;

        System.out.println("Media com 3 notas = "
                + media3);

        float r1 = maiorNota.calculaMaiorValor(a, b);

        float r2 = maiorNota.calculaMaiorValor(b, c);

        float media2 = (r1 + r2) / 2;
        System.out.println("Media das duas notas mais altas "
                + media2);
        
        r1 = menorNota.calculaMenorValor(a, b);
        r2 = menorNota.calculaMenorValor(b, c);
        
        
        

    }

}
