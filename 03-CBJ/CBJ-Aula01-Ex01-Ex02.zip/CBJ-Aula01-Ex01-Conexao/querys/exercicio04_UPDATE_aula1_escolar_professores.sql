/* ALTERACAO DE DADOS */

UPDATE aula1_escolar.professores SET salario=1950
WHERE nome = "Professor C";
