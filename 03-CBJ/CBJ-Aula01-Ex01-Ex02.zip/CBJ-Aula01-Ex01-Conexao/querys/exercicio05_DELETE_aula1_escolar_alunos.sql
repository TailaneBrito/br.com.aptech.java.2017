/* Exclua todo os alunos que fazem java */

DELETE FROM aula1_escolar.alunos
WHERE curso = "Java";