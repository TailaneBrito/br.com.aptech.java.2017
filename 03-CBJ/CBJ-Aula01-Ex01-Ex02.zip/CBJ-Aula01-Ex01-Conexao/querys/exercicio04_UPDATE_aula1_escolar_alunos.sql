/* ALTERACAO DE DADOS */

UPDATE aula1_escolar.alunos SET curso = "Java"
WHERE curso = "Excel";

