/* Excluir todos os professores que ganham menos que 1200 */

DELETE FROM aula1_escolar.professores
WHERE salario <= 1200;