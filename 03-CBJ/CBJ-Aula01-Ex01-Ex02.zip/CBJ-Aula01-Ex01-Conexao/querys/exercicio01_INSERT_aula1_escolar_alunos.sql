/* EXERCICIO INSERCAO DE DADOS */


INSERT INTO aula1_escolar.alunos VALUES (5,"João","Lógica");
INSERT INTO aula1_escolar.alunos VALUES (6,"Pedro","Java"); 
INSERT INTO aula1_escolar.alunos VALUES (7,"Marta","BD");
INSERT INTO aula1_escolar.alunos VALUES (8,"Lucas","BD");
INSERT INTO aula1_escolar.alunos VALUES (9,"José","Excel");