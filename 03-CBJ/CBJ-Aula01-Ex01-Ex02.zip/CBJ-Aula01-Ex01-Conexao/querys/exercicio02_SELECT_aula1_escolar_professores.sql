/* Refinamento da consulta */


SELECT nome FROM aula1_escolar.professores
WHERE salario >= 1500;