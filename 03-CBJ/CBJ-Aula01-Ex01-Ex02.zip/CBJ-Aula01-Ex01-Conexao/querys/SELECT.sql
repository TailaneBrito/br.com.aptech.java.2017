/* COMANDO SELECT */
SELECT * FROM aula1_escolar.alunos; 




