/* EXERCICIO INSERCAO DE DADOS */

INSERT INTO aula1_escolar.professores VALUES (100,"Professor A",1000);
INSERT INTO aula1_escolar.professores VALUES (200,"Professor B",1200);
INSERT INTO aula1_escolar.professores VALUES (300,"Professor C",900);
INSERT INTO aula1_escolar.professores VALUES (400,"Professor D",1500);
INSERT INTO aula1_escolar.professores VALUES (500,"Professor E",1700);