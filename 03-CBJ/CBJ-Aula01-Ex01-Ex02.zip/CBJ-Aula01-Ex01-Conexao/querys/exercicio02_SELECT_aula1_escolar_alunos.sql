/* Refinamento da consulta */

SELECT curso, matricula FROM aula1_escolar.alunos
WHERE nome = "Tailane";