/* COMANDO INSERT
INSERT INTO aula1_escolar.alunos VALUES (1,"Maria","Lógica");
INSERT INTO aula1_escolar.alunos VALUES (2,"Tailane","Programação Java");
INSERT INTO aula1_escolar.alunos VALUES (3,"Marcio","Excel Avançado");
INSERT INTO aula1_escolar.alunos VALUES (4,"Carlos","Excel Avançado");
*/