/* INSERT LOCACOES */

INSERT INTO roda_dura.locacoes VALUES (1002,"Gol","Pedro","Praça da Sé",12345678);
INSERT INTO roda_dura.locacoes VALUES (1004,"Civic","Joao","Anhangabaú",87654321);
INSERT INTO roda_dura.locacoes VALUES (1006,"Civic","Marta","Ibirapuera",14785236);
INSERT INTO roda_dura.locacoes VALUES (1008,"Fit","Jose","Paulista",36985214);
INSERT INTO roda_dura.locacoes VALUES (1010,"Meriva","Maria","Consolação",78562185);