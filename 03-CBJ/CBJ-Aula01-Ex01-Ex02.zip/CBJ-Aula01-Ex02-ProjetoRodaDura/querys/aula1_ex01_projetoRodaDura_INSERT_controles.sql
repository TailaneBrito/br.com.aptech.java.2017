/* INSERT CONTROLE */

INSERT INTO roda_dura.controle VALUES (100,"Salário Funcionários",500,"Despesa");
INSERT INTO roda_dura.controle VALUES (200,"Locações Veículos",60000,"Receita");
INSERT INTO roda_dura.controle VALUES (300,"Aluguel Loja",1500,"Despesa");
INSERT INTO roda_dura.controle VALUES (400,"Internet",100,"Despesa");
INSERT INTO roda_dura.controle VALUES (500,"Outros",10000,"Receita");