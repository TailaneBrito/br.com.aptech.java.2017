/* insert frota */

INSERT INTO roda_dura.frota VALUES (001,"Gol",2006,"Alcool","Volkswagem");
INSERT INTO roda_dura.frota VALUES (002,"Civic",2009,"Gasolina","Honda");
INSERT INTO roda_dura.frota VALUES (003,"Meriva",1998,"Gasolina","Chevrolet");
INSERT INTO roda_dura.frota VALUES (004,"Fiesta",2013,"Alcool","Ford");
INSERT INTO roda_dura.frota VALUES (005,"Fit",2012,"Alcool","Honda");



