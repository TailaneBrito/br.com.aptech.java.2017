/* Exibir um relatório dos alugueis dos veículos. Esse relatório deverá exibir 
o nome do locador, marca do carro, endereço e telefone. */

SELECT locador, marca_carro, endereco_locador, telefone_locador FROM roda_dura.locacoes;
 