/* Alterar os gastos com salário de funcionários para R$ 8.000 */

UPDATE roda_dura.controle SET valor = 8000
WHERE id_controle = 100;